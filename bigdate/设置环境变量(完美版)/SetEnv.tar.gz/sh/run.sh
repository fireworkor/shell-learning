#!/bin/bash

'set.sh' /etc/profile names set
