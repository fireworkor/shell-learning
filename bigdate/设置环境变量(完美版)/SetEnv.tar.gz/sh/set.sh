#!/bin/bash

#	添加环境变量
#	eg:bash set.sh /etc/profile names set
#要修改的文件
file1=$1
#修改的字段名称
file2=$2
#添加内容文件
addfile=$3
# 从文件中获取要设置的变量
names=`cat $file2`

if [ $# -lt 2 ];then
echo "please Usage:changedfile names set"
exit 1
fi

for name in $names
do
   #将有关键字的行删除
	ISNEED=`cat $file1 | grep ".*$name.*$"` 
	if [ "$ISNEED" != "" ];then
	echo "#######找到$3中的$name#######################"
	sed -i '/.*'$name'.*$/d' $file1
	echo "#######成功删除$3中的$name###################"
	else
	echo "#######没有找到$3中的$name###################"
	fi
done

#将环境变量添加进去文件中
cat $addfile >> $file1 
echo "#######成功添加了环境变量###################"


